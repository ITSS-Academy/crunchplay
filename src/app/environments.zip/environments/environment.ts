export const environment = {
  production: false,
  supabase_url: 'https://brpguibxcencsjnuyewo.supabase.co',
  supabase_anon_key: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJycGd1aWJ4Y2VuY3NqbnV5ZXdvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTYzNjkxNzIsImV4cCI6MjA3MTk0NTE3Mn0.Fn_1tD-QWBLQE5FUCmDKtvGNG5xqF7gNeoFCmHbF7Ro',
  api_base_url: 'http://localhost:3000'
};
